<footer class="container-fluid">
    <div class="container">
<div class="row">
    <div class="col-md-6">
        <p> JOSH WHITKEN

        </p>
    </div>

    <div class="col-md-6">
        <p> Terms and Conditions
        </p>
    </div> 


</div><!-- row -->
    </div> <!-- container -->
</footer> <!-- container-fluid -->

</section>

<?php wp_footer(); ?>

</body>
</html>